"use client"

import React, { useState } from "react";
import { AiFillMessage } from "react-icons/ai"; // Optional: to show a chat icon

const Chatbox = () => {
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState("");

  const handleSendMessage = () => {
    if (userInput.trim()) {
      // Add user's message
      const newMessages = [
        ...messages,
        { sender: "user", text: userInput },
      ];

      // Simulate bot response
      setMessages([
        ...newMessages,
        { sender: "bot", text: "Thank you for your message!" },
      ]);

      setUserInput(""); // Reset input field
    }
  };

  return (
    <div className="chatbox-container">
      <div className="chatbox-header">
        <AiFillMessage size={24} /> Chat with us
      </div>
      <div className="chatbox-messages">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`message ${message.sender === "user" ? "user-message" : "bot-message"}`}
          >
            <p>{message.text}</p>
          </div>
        ))}
      </div>
      <div className="chatbox-input">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Type your message..."
        />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
};

export default Chatbox;

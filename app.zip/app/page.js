import React from 'react'
// import Login from './pages/Login/page'
 import Homepage from './pages/Homepage/page'
 
const page = () => {
  return (
    <div> 
  <Homepage/>
    </div>
  )
}

export default page